package com.zorion.jarvis

import android.Manifest
import android.app.ActivityManager
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.media.*
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import android.content.ContentValues
import android.app.Dialog
import android.webkit.WebView
import java.io.ByteArrayOutputStream
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** JARVIS-style HUD. mode: 0 idle, 1 listening, 2 thinking, 3 speaking */
class Hud(c: Context, private val logo: Bitmap) : View(c) {
    var mode = 0; var level = 0f
    var left = ""; var right = ""; var caption = ""
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val d = resources.displayMetrics.density

    override fun onDraw(cv: Canvas) {
        t += 0.02f
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2 - 8 * d
        val base = min(w, h) * 0.27f
        val col = when (mode) { 1 -> 0xFF7CFF6B; 2 -> 0xFFB388FF; 3 -> 0xFFFFB300; else -> 0xFF29E0FF }.toInt()
        // grid
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0x2229E0FF
        var x = 0f; while (x < w) { cv.drawLine(x, 0f, x, h, p); x += 28 * d }
        var y = 0f; while (y < h) { cv.drawLine(0f, y, w, y, p); y += 28 * d }
        // rotating arc-reactor rings
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0..3) {
            val r = base * (1.0f + i * 0.2f)
            p.strokeWidth = (5 - i) * d; p.color = col; p.alpha = 230 - i * 40
            val s = t * 50f * (if (i % 2 == 0) 1 else -1) * (1 + i * 0.5f)
            val rect = RectF(cx - r, cy - r, cx + r, cy + r)
            cv.drawArc(rect, s, 80f + i * 20f, false, p)
            cv.drawArc(rect, s + 180f, 80f + i * 20f, false, p)
        }
        // core glow + logo
        p.style = Paint.Style.FILL; p.color = col
        val boost = level + (if (mode == 3) 0.5f + 0.4f * sin(t * 8) else 0f)
        p.alpha = (40 + 60 * boost).toInt().coerceIn(0, 255)
        cv.drawCircle(cx, cy, base * (0.95f + 0.1f * level), p)
        p.alpha = 255
        val lr = base * 0.62f
        cv.drawBitmap(logo, null, RectF(cx - lr, cy - lr, cx + lr, cy + lr), p)
        // waveform
        p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = col; p.alpha = 200
        val n = 40; val by = h - 14 * d
        for (i in 0 until n) {
            val amp = (0.15f + level + (if (mode == 3) 0.5f else if (mode == 2) 0.2f else 0f)) * abs(sin(t * 4 + i * 0.6f))
            val bx = w * 0.1f + i * (w * 0.8f / n)
            cv.drawLine(bx, by, bx, by - amp * 34 * d, p)
        }
        // HUD text
        p.style = Paint.Style.FILL; p.textSize = 11 * d; p.color = col; p.alpha = 255; p.typeface = Typeface.MONOSPACE
        p.textAlign = Paint.Align.LEFT; var ly = 20 * d
        for (line in left.split("\n")) { cv.drawText(line, 12 * d, ly, p); ly += 14 * d }
        p.textAlign = Paint.Align.RIGHT; ly = 20 * d
        for (line in right.split("\n")) { cv.drawText(line, w - 12 * d, ly, p); ly += 14 * d }
        p.textAlign = Paint.Align.CENTER; p.color = 0xFFD8F6FF.toInt(); p.textSize = 13 * d
        if (caption.isNotEmpty()) cv.drawText(caption.takeLast(40), cx, h - 52 * d, p)
        postInvalidateOnAnimation()
    }
}

class MainActivity : Activity() {
    private data class P(val url: String, val model: String, val key: String)
    private val groq = "https://api.groq.com/openai/v1"
    private val gem = "https://generativelanguage.googleapis.com/v1beta/openai"
    private val providers = listOf(
        P(groq, "openai/gpt-oss-120b", "groq"), P(gem, "gemini-2.5-flash", "gemini"),
        P(groq, "openai/gpt-oss-20b", "groq"), P(gem, "gemini-2.5-flash-lite", "gemini")
    )
    private val voices = listOf("Charon", "Algieba", "Orus", "Fenrir", "Puck")

    private lateinit var prefs: SharedPreferences
    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var hud: Hud
    private lateinit var liveBtn: Button
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null
    private var audio: AudioTrack? = null
    private val main = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>()
    private var live = false
    private var lowWarned = false
    private var lastSeen = 0L
    private var pending: List<String>? = null
    private var pendingVideo = false
    private var lastHtml: String? = null

    private fun sys(): String {
        val mem = (prefs.getString("mem", "") ?: "").trim()
        return "You are ZORIN-M4 (ZORION), a Jarvis-style AI assistant on the user's phone. Address the user as 'boss'. " +
            "Speak Hinglish (Hindi in Roman letters mixed with English): calm, confident, refined, dry wit (humor 30%). " +
            "Replies must be VERY SHORT: one or two short sentences, spoken aloud." +
            (if (mem.isNotEmpty()) "\nThings the user asked you to remember:\n$mem" else "")
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val mk = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        prefs = EncryptedSharedPreferences.create(
            this, "zorion", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        try {
            val a = JSONArray(prefs.getString("hist", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); history.add(o.getString("r") to o.getString("t")) }
        } catch (e: Exception) { }
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val vs = tts?.voices?.filter { it.locale.language == "en" && it.locale.country == "GB" }
                val pick = vs?.firstOrNull { it.name.contains("rjs") || it.name.contains("gbd") } ?: vs?.firstOrNull()
                if (pick != null) tts?.voice = pick else tts?.language = Locale("en", "GB")
                tts?.setPitch(0.8f); tts?.setSpeechRate(0.95f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onError(id: String?) { spoken() }
                    override fun onDone(id: String?) { spoken() }
                })
            }
        }
        buildUi()
        say("ZORIN-M4 online hai, boss. All systems ready. Bolo, kya karna hai?")
        if (prefs.getString("groq", "").isNullOrBlank() && prefs.getString("gemini", "").isNullOrBlank()) settings()
        shared(intent)
    }

    private val tick = object : Runnable { override fun run() { stats(); main.postDelayed(this, 5000) } }

    override fun onStart() {
        super.onStart()
        if (lastSeen > 0 && System.currentTimeMillis() - lastSeen > 20 * 60000) say("Welcome back, boss.")
        main.post(tick)
    }

    override fun onStop() { lastSeen = System.currentTimeMillis(); main.removeCallbacks(tick); super.onStop() }

    private fun stats() {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val mi = ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ram = ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt()
        hud.left = "SYS ONLINE\nBAT $bat%" + (if (chg) " +" else "") + "\nRAM $ram%" + (if (live) "\nLIVE" else "")
        hud.right = SimpleDateFormat("HH:mm\nEEE d MMM", Locale.getDefault()).format(Date())
        if (bat <= 15 && !chg && !lowWarned) { lowWarned = true; say("Boss, battery sirf $bat% reh gayi hai.") }
        if (bat > 20 || chg) lowWarned = false
    }

    private fun report(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val mi = ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val sf = StatFs(Environment.getDataDirectory().path)
        val free = sf.availableBytes / 1_000_000_000
        val tot = sf.totalBytes / 1_000_000_000
        return "Battery ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%, RAM ${((mi.totalMem - mi.availMem) * 100 / mi.totalMem)}% used, storage mein $free GB free of $tot GB, boss."
    }

    private fun spoken() = runOnUiThread { hud.mode = 0; if (live) main.postDelayed({ listen() }, 400) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF050B14.toInt()); fitsSystemWindows = true }
        hud = Hud(this, BitmapFactory.decodeResource(resources, R.drawable.zorion))
        hud.setOnClickListener { stopSpeaking(); if (live) listen() }
        root.addView(hud, LinearLayout.LayoutParams(-1, 0, 0.85f))
        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(4)) }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val chips = LinearLayout(this).apply { setPadding(dp(8), dp(2), dp(8), dp(2)) }
        listOf("Snake game banao", "Sher ki photo banao", "System status", "Open Chrome", "Kya yaad hai").forEach { c ->
            chips.addView(Button(this).apply { text = c; textSize = 12f; isAllCaps = false; setTextColor(0xFF29E0FF.toInt()); setOnClickListener { handle(c) } })
        }
        root.addView(HorizontalScrollView(this).apply { addView(chips); isHorizontalScrollBarEnabled = false })
        val row = LinearLayout(this).apply { setPadding(dp(8), dp(4), dp(8), dp(6)); gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = "Zorin se bolo…"; setHintTextColor(0xFF6B8BA0.toInt()); setTextColor(0xFFD8F6FF.toInt()); maxLines = 3 }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        liveBtn = Button(this).apply { text = "LIVE"; setOnClickListener { toggleLive() } }
        row.addView(Button(this).apply { text = "📎"; setOnClickListener { pick() } })
        row.addView(liveBtn)
        row.addView(Button(this).apply { text = "🎤"; setOnClickListener { live = false; listen() } })
        row.addView(Button(this).apply { text = "⚙"; setOnClickListener { settings() } })
        root.addView(row)
        for (i in 0 until row.childCount) (row.getChildAt(i) as? Button)?.apply { minWidth = 0; minimumWidth = 0; setPadding(dp(10), 0, dp(10), 0) }
        setContentView(root)
        input.setOnEditorActionListener { _, _, _ -> send(); true }
    }

    private fun bubble(t: String, me: Boolean): TextView {
        val tv = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(0xFFD8F6FF.toInt()); setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(if (me) 0xFF0E3A52.toInt() else 0xCC0B1626.toInt()); setStroke(dp(1), 0x6629E0FF); cornerRadius = dp(12).toFloat()
            }
        }
        log.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { gravity = if (me) Gravity.END else Gravity.START; setMargins(0, dp(4), 0, dp(4)) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun say(t: String) { bubble(t, false); speak(t) }

    // ---------- voice output: Gemini "Jarvis" voice, fallback to British system voice ----------
    private fun speak(t: String) {
        stopSpeaking(); hud.mode = 3
        val clean = t.replace(Regex("[*#`_]"), "")
        if (prefs.getBoolean("gv", true) && !prefs.getString("gemini", "").isNullOrBlank()) {
            Thread {
                val pcm = try { geminiTts(clean) } catch (e: Exception) { null }
                runOnUiThread { if (pcm != null) play(pcm) else sysSpeak(clean) }
            }.start()
        } else sysSpeak(clean)
    }

    private fun sysSpeak(t: String) {
        val r = tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "z")
        if (r != TextToSpeech.SUCCESS) spoken()
    }

    private fun stopSpeaking() {
        tts?.stop()
        audio?.let { try { it.stop(); it.release() } catch (e: Exception) { } }
        audio = null; hud.mode = 0
    }

    private fun geminiTts(text: String): ByteArray? {
        val key = prefs.getString("gemini", "") ?: return null
        val voice = prefs.getString("voice", "Charon") ?: "Charon"
        val prompt = "Say in a calm, refined British male AI butler voice, understated, dry wit, natural pace: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 20000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) return null
        val d = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        return Base64.decode(d, Base64.DEFAULT)
    }

    private fun play(pcm: ByteArray) {
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size).setTransferMode(AudioTrack.MODE_STATIC).build()
        tr.write(pcm, 0, pcm.size)
        tr.setNotificationMarkerPosition(pcm.size / 2)
        tr.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack?) { try { tr.release() } catch (e: Exception) { }; spoken() }
            override fun onPeriodicNotification(t: AudioTrack?) {}
        })
        audio = tr; hud.mode = 3; tr.play()
    }

    private fun settings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        fun field(h: String, k: String) = EditText(this).apply {
            hint = h + if (!prefs.getString(k, "").isNullOrBlank()) " (saved ✓)" else ""
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val g = field("Groq API key", "groq"); val m = field("Gemini API key", "gemini")
        val gv = CheckBox(this).apply { text = "Jarvis voice (Gemini)"; isChecked = prefs.getBoolean("gv", true) }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices)
            setSelection(voices.indexOf(prefs.getString("voice", "Charon")).coerceAtLeast(0))
        }
        box.addView(g); box.addView(m); box.addView(gv); box.addView(sp)
        AlertDialog.Builder(this).setTitle("ZORIN-M4 settings").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val e = prefs.edit()
                if (g.text.isNotBlank()) e.putString("groq", g.text.toString().trim())
                if (m.text.isNotBlank()) e.putString("gemini", m.text.toString().trim())
                e.putBoolean("gv", gv.isChecked).putString("voice", voices[sp.selectedItemPosition]).apply()
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------- voice input / LIVE ----------
    private fun toggleLive() {
        live = !live
        liveBtn.setTextColor(if (live) 0xFF7CFF6B.toInt() else 0xFFFFFFFF.toInt())
        if (live) listen() else { sr?.cancel(); stopSpeaking() }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { live = false; say("Boss, is phone pe voice recognition available nahi hai."); return }
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr!!.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    hud.caption = ""
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t != null) handle(t) else again()
                }
                override fun onError(e: Int) {
                    hud.mode = 0; hud.caption = ""
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) live = false
                    else { if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) sr?.cancel(); again() }
                }
                override fun onRmsChanged(v: Float) { hud.level = ((v + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onPartialResults(b: Bundle?) { hud.caption = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "" }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { hud.level = 0f }
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        hud.mode = 1
        sr!!.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }

    private fun again() { if (live) main.postDelayed({ listen() }, 1200) }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 2 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
    }

    private fun send() { val q = input.text.toString(); input.setText(""); handle(q) }

    private fun handle(q0: String) {
        val q = q0.replace(Regex("(?i)\\b(zorin|zorion|ज़ोरिन|जोरिन)\\b[, ]*"), "").trim()
        if (q.isEmpty()) { if (q0.isNotBlank()) say("Ji boss?") else again(); return }
        bubble(q, true)
        val att = pending
        if (att != null) {
            pending = null; hud.mode = 2
            val tv = bubble("…", false)
            Thread { val a = vision(q, att); runOnUiThread { tv.text = a; speak(a) } }.start(); return
        }
        if (isBuild(q) || (lastHtml != null && Regex("^(change|badlo|modify|fix|isme)\\b").containsMatchIn(q.lowercase()))) { build(q); return }
        if (isImage(q)) { genImage(q); return }
        val r = try { local(q) } catch (e: Exception) { "Ye action fail ho gaya, boss: ${e.message}" }
        if (r != null) { say(r); return }
        hud.mode = 2
        val tv = bubble("…", false)
        Thread {
            val a = chat(q)
            runOnUiThread { tv.text = a; speak(a) }
        }.start()
    }

    private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }

    private fun media(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun local(q: String): String? {
        val l = q.lowercase()
        Regex("^(?:remember|yaad rakh(?:o)?)\\s+(.+)").find(l)?.let {
            prefs.edit().putString("mem", ((prefs.getString("mem", "") ?: "") + "\n- " + it.groupValues[1]).trim()).apply(); return "Yaad rakh liya, boss."
        }
        if (Regex("what do you remember|kya yaad hai").containsMatchIn(l)) {
            val m = (prefs.getString("mem", "") ?: "").trim(); return if (m.isEmpty()) "Abhi kuch yaad nahi hai, boss." else m
        }
        if (Regex("forget everything|sab bhool ja").containsMatchIn(l)) { prefs.edit().remove("mem").remove("hist").apply(); history.clear(); return "Sab bhool gaya, boss." }
        if (Regex("system status|battery|\\bram\\b|storage").containsMatchIn(l)) return report()
        if (Regex("screenshot").containsMatchIn(l)) return "Boss, app se screenshot nahi le sakta. Power plus volume down dabao."
        if (Regex("downloads").containsMatchIn(l) && Regex("open|kholo|khol").containsMatchIn(l)) { go(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); return "Downloads khol raha hoon." }
        Regex("volume\\s+(up|down)").find(l)?.let {
            (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC,
                if (it.groupValues[1] == "up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return "Done, boss."
        }
        if (Regex("pause music|music pause|stop music").containsMatchIn(l)) { media(KeyEvent.KEYCODE_MEDIA_PAUSE); return "Music pause." }
        if (Regex("resume music|play music").containsMatchIn(l)) { media(KeyEvent.KEYCODE_MEDIA_PLAY); return "Music chala diya." }
        if (Regex("next song|next track").containsMatchIn(l)) { media(KeyEvent.KEYCODE_MEDIA_NEXT); return "Next song." }
        Regex("(?:call|dial)\\s+(\\+?[\\d ]{5,})").find(l)?.let {
            go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + it.groupValues[1].replace(" ", "")))); return "Dial kar raha hoon, boss. Call button dabao."
        }
        Regex("(?:sms|text)\\s+(\\+?\\d{5,})\\s+(.+)").find(l)?.let {
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + it.groupValues[1])).putExtra("sms_body", it.groupValues[2])); return "Message ready hai, send dabao."
        }
        Regex("whatsapp\\s+(\\+?\\d{5,})\\s+(.+)").find(l)?.let {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + it.groupValues[1].removePrefix("+") + "?text=" + Uri.encode(it.groupValues[2])))); return "WhatsApp khol raha hoon."
        }
        Regex("(?:navigate to|directions to)\\s+(.+)").find(l)?.let { go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(it.groupValues[1])))); return "Navigation shuru, boss." }
        Regex("^(?:search|google)\\s+(.+)").find(l)?.let { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[1])))); return "Search kar raha hoon." }
        Regex("^play\\s+(.+)").find(l)?.let { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[1])))); return "YouTube pe chala raha hoon." }
        Regex("alarm\\s+(?:at\\s+)?(\\d{1,2})[: ](\\d{2})").find(l)?.let {
            go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, it.groupValues[1].toInt())
                .putExtra(AlarmClock.EXTRA_MINUTES, it.groupValues[2].toInt()).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Alarm set, ${it.groupValues[1]}:${it.groupValues[2]} pe."
        }
        Regex("timer\\s+(\\d+)\\s*(min|sec)").find(l)?.let {
            val s = it.groupValues[1].toInt() * (if (it.groupValues[2] == "min") 60 else 1)
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_SKIP_UI, true)); return "Timer start, boss."
        }
        if (Regex("flashlight|torch").containsMatchIn(l)) {
            val on = !Regex("\\boff\\b|band").containsMatchIn(l)
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on); return if (on) "Torch on." else "Torch off."
        }
        if (l.contains("wifi")) { go(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Wi-Fi settings khol di." }
        if (l.contains("bluetooth")) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Bluetooth settings khol di." }
        if (Regex("\\b(time|samay)\\b").containsMatchIn(l)) return SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) + " ho rahe hain, boss."
        val name = (Regex("^open\\s+(.+)").find(l)?.groupValues?.get(1)
            ?: Regex("^(.+?)\\s+(?:kholo|khol do|open karo)$").find(l)?.groupValues?.get(1))?.trim()
        if (name != null) {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            val i = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            return if (i != null) { go(i); "${hit.loadLabel(pm)} khol raha hoon." } else "$name naam ka app nahi mila, boss."
        }
        return null
    }

    // ---------- photos / videos IN (attach button or Share -> ZORION) ----------
    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*")).addCategory(Intent.CATEGORY_OPENABLE), 7)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 7 && c == RESULT_OK) d?.data?.let { attach(it) }
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); i?.let { shared(it) } }

    @Suppress("DEPRECATION")
    private fun shared(i: Intent) {
        if (i.action == Intent.ACTION_SEND) i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { attach(it) }
    }

    private fun b64(b: Bitmap, max: Int = 1024): String {
        val k = max.toFloat() / maxOf(b.width, b.height)
        val bb = if (k < 1f) Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true) else b
        val o = ByteArrayOutputStream(); bb.compress(Bitmap.CompressFormat.JPEG, 80, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun attach(u: Uri) {
        Thread {
            val frames = mutableListOf<String>(); var video = false
            try {
                if ((contentResolver.getType(u) ?: "").startsWith("video")) {
                    video = true
                    val mr = MediaMetadataRetriever(); mr.setDataSource(this, u)
                    val dur = (mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) ?: "0").toLong() * 1000
                    for (k in 0 until 4) mr.getFrameAtTime(dur * k / 4 + 100000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { frames.add(b64(it, 768)) }
                    mr.release()
                } else {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
                    o.inJustDecodeBounds = false; o.inSampleSize = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1536)
                    contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }?.let { frames.add(b64(it)) }
                }
            } catch (e: Exception) { }
            runOnUiThread {
                if (frames.isEmpty()) say("Boss, ye file nahi padh paaya.")
                else {
                    pending = frames; pendingVideo = video
                    say((if (video) "Video" else "Photo") + " mil gayi, boss. Ab bolo ya likho, kya karna hai iska?")
                }
            }
        }.start()
    }

    private fun openai(base: String, key: String, model: String, msgs: JSONArray, maxTok: Int, timeout: Int): String {
        val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = timeout
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Authorization", "Bearer $key")
        c.outputStream.use { it.write(JSONObject().put("model", model).put("messages", msgs).put("max_tokens", maxTok).toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw Exception("HTTP ${c.responseCode}")
        return JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
    }

    private fun vision(q: String, imgs: List<String>): String {
        val key = prefs.getString("gemini", "") ?: ""
        if (key.isBlank()) return "Boss, photo ya video dekhne ke liye Gemini key chahiye (⚙)."
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", (if (pendingVideo) "These are 4 frames from one video, in order. " else "") + q))
        imgs.forEach { content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$it"))) }
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sys()))
            .put(JSONObject().put("role", "user").put("content", content))
        return try { openai(gem, key, "gemini-2.5-flash", msgs, 1500, 60000) } catch (e: Exception) { "Dekh nahi paaya, boss. (${e.message})" }
    }

    // ---------- build games / apps (opens inside ZORION) ----------
    private fun isBuild(q: String): Boolean {
        val l = q.lowercase()
        return Regex("\\b(game|app|website|calculator|tool|quiz)\\b").containsMatchIn(l) &&
            Regex("banao|bana do|bana de|\\bbuild\\b|\\bmake\\b|\\bcreate\\b|develop").containsMatchIn(l) && !l.contains("open ")
    }

    private fun build(q: String) {
        hud.mode = 2
        val tv = bubble("Bana raha hoon, boss… (1-2 minute lag sakte hain)", false)
        val prev = lastHtml
        Thread {
            val res = try { codegen(q, prev) } catch (e: Exception) { null }
            runOnUiThread {
                if (res == null) { tv.text = "Build fail ho gaya, boss. Phir se try karo."; speak(tv.text.toString()) }
                else { lastHtml = res; tv.text = "Ready hai, boss!"; speak("Ready hai, boss."); showHtml(res); actionBubble("▶ Open again") { showHtml(res) } }
            }
        }.start()
    }

    private fun codegen(q: String, prev: String?): String? {
        val sysP = "You are an expert game and app developer. Output ONE complete self-contained HTML file (inline CSS and JS, no external files or libraries), " +
            "mobile-first with touch controls, responsive full-screen, dark neon style, polished and fully working. Return ONLY the code in a single ```html block."
        val user = if (prev != null) "Current file:\n$prev\n\nApply this change and return the full updated file: $q" else q
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sysP)).put(JSONObject().put("role", "user").put("content", user))
        for (p in providers.sortedBy { if (it.key == "gemini") 0 else 1 }) {
            val k = prefs.getString(p.key, "") ?: ""
            if (k.isBlank()) continue
            try {
                val t = openai(p.url, k, p.model, msgs, 12000, 150000)
                val m = Regex("```(?:html)?\\s*([\\s\\S]*?)```").find(t)
                val code = (m?.groupValues?.get(1) ?: t.removePrefix("```html").removePrefix("```")).trim()
                if (code.contains("<script", true) || code.contains("<html", true)) return code
            } catch (e: Exception) { }
        }
        return null
    }

    private fun showHtml(html: String) {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; setBackgroundColor(0xFF050B14.toInt()) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(Button(this).apply { text = "✕ Close"; setOnClickListener { dlg.dismiss() } })
        bar.addView(Button(this).apply { text = "⬇ Save"; setOnClickListener { saveHtml(html)?.let { Toast.makeText(this@MainActivity, "Downloads/ZORION mein save", Toast.LENGTH_SHORT).show() } } })
        bar.addView(Button(this).apply { text = "↗ Share"; setOnClickListener { saveHtml(html)?.let { shareUri(it, "text/html") } } })
        val wv = WebView(this).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; loadDataWithBaseURL(null, html, "text/html", "utf-8", null) }
        box.addView(bar); box.addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        dlg.setContentView(box); dlg.show()
    }

    private fun saveHtml(html: String): Uri? {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "zorion_${System.currentTimeMillis()}.html")
            put(MediaStore.MediaColumns.MIME_TYPE, "text/html"); put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ZORION")
        }
        val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
        contentResolver.openOutputStream(u)?.use { it.write(html.toByteArray()) }
        return u
    }

    private fun shareUri(u: Uri, type: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(type).putExtra(Intent.EXTRA_STREAM, u)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"))
    }

    private fun actionBubble(label: String, onClick: () -> Unit) {
        log.addView(Button(this).apply { text = label; isAllCaps = false; setTextColor(0xFF29E0FF.toInt()); setOnClickListener { onClick() } },
            LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.START })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ---------- generate photos ----------
    private fun isImage(q: String): Boolean {
        val l = q.lowercase()
        return Regex("\\b(image|photo|picture|pic|tasveer|wallpaper|poster|logo)\\b").containsMatchIn(l) &&
            Regex("banao|bana do|bana de|generate|\\bmake\\b|\\bcreate\\b|\\bdraw\\b").containsMatchIn(l)
    }

    private fun genImage(q: String) {
        hud.mode = 2
        val tv = bubble("Image bana raha hoon, boss…", false)
        Thread {
            var bmp: Bitmap? = null
            try { bmp = geminiImage(q) } catch (e: Exception) { }
            if (bmp == null) try { bmp = freeImage(q) } catch (e: Exception) { }
            runOnUiThread {
                val b = bmp
                if (b == null) { tv.text = "Image nahi ban paayi, boss."; speak(tv.text.toString()) }
                else {
                    tv.text = "Ye lo, boss."; speak("Ye lo, boss.")
                    log.addView(ImageView(this).apply { setImageBitmap(b); adjustViewBounds = true },
                        LinearLayout.LayoutParams(dp(260), -2).apply { gravity = Gravity.START; setMargins(0, dp(4), 0, dp(4)) })
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, "zorion_${System.currentTimeMillis()}.jpg")
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg"); put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/ZORION")
                    }
                    val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    if (u != null) {
                        contentResolver.openOutputStream(u)?.use { b.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                        actionBubble("↗ Share image") { shareUri(u, "image/jpeg") }
                    }
                }
            }
        }.start()
    }

    private fun geminiImage(q: String): Bitmap? {
        val key = prefs.getString("gemini", "") ?: ""
        if (key.isBlank()) return null
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Generate an image: $q")))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 90000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) return null
        val parts = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        for (i in 0 until parts.length()) {
            val inl = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
            val b = Base64.decode(inl.getString("data"), Base64.DEFAULT)
            return BitmapFactory.decodeByteArray(b, 0, b.size)
        }
        return null
    }

    // free fallback (no key): prompt is sent to pollinations.ai
    private fun freeImage(q: String): Bitmap? {
        val c = URL("https://image.pollinations.ai/prompt/" + Uri.encode(q) + "?width=768&height=768&nologo=true").openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 90000
        if (c.responseCode !in 200..299) return null
        val b = c.inputStream.readBytes()
        return BitmapFactory.decodeByteArray(b, 0, b.size)
    }

    // ---------- AI brain with fallback ----------
    private fun chat(q: String): String {
        val keys = providers.filter { !prefs.getString(it.key, "").isNullOrBlank() }
        if (keys.isEmpty()) return "Boss, pehle settings (⚙) mein API key daalo."
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sys()))
        history.takeLast(12).forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        msgs.put(JSONObject().put("role", "user").put("content", q))
        var err = ""
        for (p in keys) {
            try {
                val c = URL(p.url + "/chat/completions").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 10000; c.readTimeout = 18000
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("Authorization", "Bearer " + prefs.getString(p.key, ""))
                c.outputStream.use { it.write(JSONObject().put("model", p.model).put("messages", msgs).toString().toByteArray()) }
                val ok = c.responseCode in 200..299
                val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
                if (!ok) { err = "${p.model}: HTTP ${c.responseCode}"; continue }
                val a = JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
                history.add("user" to q); history.add("assistant" to a)
                val arr = JSONArray(); history.takeLast(20).forEach { arr.put(JSONObject().put("r", it.first).put("t", it.second)) }
                prefs.edit().putString("hist", arr.toString()).apply()
                return a
            } catch (e: Exception) { err = "${p.model}: ${e.message}" }
        }
        return "Sab providers fail ho gaye, boss. ($err)"
    }

    override fun onDestroy() { live = false; stopSpeaking(); sr?.destroy(); tts?.shutdown(); super.onDestroy() }
}
